TODO: 

1. Implementere et heisobjekt med flere lagrede verdier osv. 
2. Få en heis til å fungere.
3. 

