fn main() {
    let name = "World"; let greeting = format!("Hello, {}!", name);
}
