# Nyttige rust kommandoer

## Åpne rust dokumentasjon lokalt
- `rustup doc`

## Generere dokumentasjon
Uten ikke-public kode
- `cargo doc --open`

Inklusiv ikke-public kode
- `cargo doc --open --document-private-items`

## Automatisk formatering av kode
- `cargo fmt`